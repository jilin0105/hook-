package com.hook.log

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

class FloatService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var floatView: ImageView
    private var lastX = 0f
    private var lastY = 0f

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        createFloatView()
        startForeground(1, buildNotification())
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "float_channel", "FloatService",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "悬浮球服务通知渠道" }
            (getSystemService(NotificationManager::class.java)).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val intent = Intent(this, LogViewerActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, "float_channel")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_content))
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun createFloatView() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        floatView = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_menu_report)
            setColorFilter(ContextCompat.getColor(this@FloatService, android.R.color.holo_blue_bright))
            setOnClickListener { HookEntry.launchViewer(this@FloatService) }
            setOnTouchListener(FloatTouchListener())
        }

        val params = WindowManager.LayoutParams(
            120, 120,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.START or Gravity.TOP
            x = 0
            y = 300
        }
        windowManager.addView(floatView, params)
    }

    inner class FloatTouchListener : View.OnTouchListener {
        override fun onTouch(v: View?, event: MotionEvent?): Boolean {
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = event.rawX
                    lastY = event.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - lastX
                    val dy = event.rawY - lastY
                    val params = v?.layoutParams as? WindowManager.LayoutParams ?: return true
                    params.x += dx.toInt()
                    params.y += dy.toInt()
                    windowManager.updateViewLayout(v!!, params)
                    lastX = event.rawX
                    lastY = event.rawY
                }
            }
            return true
        }
    }

    override fun onDestroy() {
        windowManager.removeViewImmediate(floatView)
        super.onDestroy()
    }

    override fun onBind(p0: Intent?) = null
}
