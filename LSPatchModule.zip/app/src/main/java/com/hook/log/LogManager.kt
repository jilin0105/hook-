package com.hook.log

import android.util.Log

object LogManager {
    private const val MAX_LOGS = 500
    private val logs = mutableListOf<LogItem>()
    private val observers = mutableListOf<() -> Unit>()
    var isPaused = false

    data class LogItem(
        val time: String,
        val content: String
    )

    fun add(content: String) {
        if (isPaused) return
        val time = java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.getDefault())
            .format(java.util.Date())
        val item = LogItem(time, content)
        synchronized(logs) {
            logs.add(0, item)
            if (logs.size > MAX_LOGS) logs.removeLast()
        }
        observers.forEach { it() }
    }

    fun getLogs(): List<LogItem> = synchronized(logs) { logs.toList() }

    fun clear() {
        synchronized(logs) { logs.clear() }
        observers.forEach { it() }
    }

    fun registerObserver(observer: () -> Unit) { observers.add(observer) }
    fun unregisterObserver(observer: () -> Unit) { observers.remove(observer) }
}
