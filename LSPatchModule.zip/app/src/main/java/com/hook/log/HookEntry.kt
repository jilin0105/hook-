package com.hook.log

import android.app.Application
import android.content.Context
import android.content.Intent
import android.util.Log
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import de.robv.android.xposed.IXposedHookLoadPackage

class HookEntry : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage?) {
        if (lpparam?.packageName != "com.kaiyu.guangying") return

        try {
            val clazz = XposedHelpers.findClass(
                "com.uex.robot.core.net.callback.RequestCallbacks",
                lpparam.classLoader
            )
            XposedBridge.hookAllMethods(clazz, "onResponse", object : XposedBridge.XC_MethodHook() {
                override fun afterHookedMethod(param: XposedBridge.XC_MethodHook.MethodHookParam) {
                    try {
                        val response = param.args[1]
                        val success = XposedHelpers.callMethod(response, "d") as Boolean
                        if (success) {
                            val body = XposedHelpers.callMethod(response, "a") as String?
                            if (!body.isNullOrEmpty()) {
                                LogManager.add(body)
                                Log.d("4K影视_Response", body)
                            }
                        }
                    } catch (e: Throwable) {
                        Log.e("4K影视_Response", "HookErr: ${e.message}")
                    }
                }
            })
            XposedBridge.log("4K影视 Hook 模块加载成功")
        } catch (e: Throwable) {
            XposedBridge.log("4K影视 Hook 失败: ${e.message}")
        }
    }

    companion object {
        fun launchViewer(context: Context) {
            val intent = Intent(context, LogViewerActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }
    }
}
